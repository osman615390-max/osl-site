OSL V5 — site vitrine premium
Ouvrir index.html dans un navigateur.
Pages : Accueil, Plomberie, Chauffage, Rénovation, Réalisations, Contact.
À personnaliser avant publication : téléphone, e-mail, coordonnées, photos réelles, avis clients, mentions légales et fonctionnement du formulaire.
Les photos externes sont des illustrations et ne représentent pas les chantiers OSL.
