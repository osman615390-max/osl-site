OSL V7 — CINEMATIC PRO

Version enrichie du site OSL :
- séquence cinématique du véhicule OSL directement en HTML/CSS/SVG/JS
- arrivée du véhicule au scroll, phares, lignes de vitesse, rotation des roues, lumière et profondeur 3D
- parallax / tilt sur ordinateur
- design mobile optimisé avec bouton d’appel fixe
- menu mobile modernisé
- barre de progression de lecture
- animations de cartes, boutons magnétiques, lumière curseur
- SEO local de base et données structurées sur la page d’accueil
- formulaire contact sans backend : ouvre le client e-mail avec le contenu du formulaire
- mention claire que le véhicule est un concept et qu’il ne représente pas un partenariat officiel
- certifications toujours affichées uniquement comme OBJECTIFS
- photos actuelles explicitement indiquées comme illustrations

Pour production réelle :
1. remplacer les photos d’illustration par les vrais chantiers OSL ;
2. connecter le formulaire à un service d’envoi ou à un backend ;
3. ajouter mentions légales / politique de confidentialité / SIRET lorsqu’ils seront disponibles ;
4. compresser et héberger les images en local pour de meilleures performances.
